"""Mock objects package"""
